mall_feat.mat contains features used in [1] and [2].
mall_gt.mat contains the ground truth.

[1] Cumulative Attribute Space for Age and Crowd Density Estimation 
K. Chen, S. Gong, T. Xiang, and C. C. Loy 
in Proceedings of IEEE Conference on Computer Vision and Pattern Recognition, 2013 (CVPR, Oral)


[2] Feature Mining for Localised Crowd Counting 
K. Chen, C. C. Loy, S. Gong, and T. Xiang 
British Machine Vision Conference, Surrey, United Kingdom, 2012 (BMVC 2012)